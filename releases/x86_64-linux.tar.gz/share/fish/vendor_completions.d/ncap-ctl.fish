# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_ncap_ctl_global_optspecs
	string join \n h/help V/version
end

function __fish_ncap_ctl_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_ncap_ctl_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_ncap_ctl_using_subcommand
	set -l cmd (__fish_ncap_ctl_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -s V -l version -d 'Print version'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "init" -d 'Evaluate the devshell, cache it, and start/restart the container'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "start" -d 'Start the container from a cached devshell'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "stop" -d 'Stop the running container'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "restart" -d 'Stop and restart the container'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "enter" -d 'Enter an interactive shell inside the devshell container'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "show-options" -d 'Print the expanded runtime arguments'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "clean" -d 'Remove all cached dev environments and nix profiles, including the current one'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "status" -d 'Show container status'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "log" -d 'Show the server log (latest log file)'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "completions" -d 'Generate shell completions'
complete -c ncap-ctl -n "__fish_ncap_ctl_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand init" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand start" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand stop" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand restart" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand enter" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand show-options" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand clean" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand status" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand log" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand completions" -s h -l help -d 'Print help'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "init" -d 'Evaluate the devshell, cache it, and start/restart the container'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "start" -d 'Start the container from a cached devshell'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "stop" -d 'Stop the running container'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "restart" -d 'Stop and restart the container'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "enter" -d 'Enter an interactive shell inside the devshell container'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "show-options" -d 'Print the expanded runtime arguments'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "clean" -d 'Remove all cached dev environments and nix profiles, including the current one'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "status" -d 'Show container status'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "log" -d 'Show the server log (latest log file)'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "completions" -d 'Generate shell completions'
complete -c ncap-ctl -n "__fish_ncap_ctl_using_subcommand help; and not __fish_seen_subcommand_from init start stop restart enter show-options clean status log completions help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
